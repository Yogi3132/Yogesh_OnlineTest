package com.capgemini.myapp.services;

import com.capgemini.myapp.dto.Question;
import com.capgemini.myapp.dto.Test;

public class UserTest {

	
	public Test addTest(Test test)
	{
		
		
		
	}
	public Test updateTest(int testId,Test test)
	{
		
	}
	
	public Test deleteTest(int testId)
	{
		
	}
	
	public boolean assignTest(long userId, int testId)
	{
		
	}
	
	public Question addQuestions(int testId,Question question)
	{
		
	}
	
	public Question updateQuestions(int testId,Question question) 
	{
		
	}
	
	public Question deleteQuestions(int testId,Question question) 
	{
		
	}
	
	public int getResult(Test test)
	{
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
