package com.capgemini.myapp.dto;

import java.io.Serializable;

public class QuePaper implements Serializable{
private int qno;
private int id;
private String que;
private String optionA;
private String optionB;
private String optionC;
private String optionD;
private int ryt;
public int getQno() {
	return qno;
}
public void setQno(int qno) {
	this.qno = qno;
}
public String getQue() {
	return que;
}
public void setQue(String que) {
	this.que = que;
}
public String getOptionA() {
	return optionA;
}
public void setOptionA(String optionA) {
	this.optionA = optionA;
}
public String getOptionB() {
	return optionB;
}
public void setOptionB(String optionB) {
	this.optionB = optionB;
}
public String getOptionC() {
	return optionC;
}
public void setOptionC(String optionC) {
	this.optionC = optionC;
}
public String getOptionD() {
	return optionD;
}
public void setOptionD(String optionD) {
	this.optionD = optionD;
}
public int getRyt() {
	return ryt;
}
public void setRyt(int ryt) {
	this.ryt = ryt;
}
	/*
	 * public QuePaper(int qno, String que, String optionA, String optionB, String
	 * optionC, String optionD, int ryt) { super(); this.qno = qno; this.que = que;
	 * this.optionA = optionA; this.optionB = optionB; this.optionC = optionC;
	 * this.optionD = optionD; this.ryt = ryt; }
	 */
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}

}
