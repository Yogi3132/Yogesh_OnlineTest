package com.capgemini.myapp.services;

public class TestService {

	
	
	public int calculateTotalMarks()
	{
		int r=0;
		return r;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
