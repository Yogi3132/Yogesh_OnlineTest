package com.capgemini.myapp.exe;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.myapp.dto.*;
import com.capgemini.myapp.services.QuestionsService;


public class MainClass implements Serializable {
	
	public static void main(String[] args) throws IOException {
		List<QuePaper> list=new ArrayList<QuePaper>();
		Map<Integer, String> map = new HashMap<Integer, String>();
		Map<Integer, String> questions = new HashMap<Integer, String>();
		Map<Integer, String> answers = new HashMap<Integer, String>();
		map.put(1, "admin");
		map.put(2, "user");
		int k=0;
		
		Test test = new Test();
		User user = new User();
		Question question=new Question();
		QuestionsService qs=new QuestionsService();
		
		Scanner sc = new Scanner(System.in);
		String q,a;
		System.out.println("-----------------WELCOME TO ONLINE TEST--------------------");
		System.out.println("Enter user Id 1-Admin login or 2-User login");
		int userId = sc.nextInt();
		sc.nextLine();
		System.out.println("�nter Password");
		String password = sc.nextLine();
		
		
		if (userId == 1 && password.equalsIgnoreCase(map.get(1)))
		{
			System.out.println("-------------------Admin Login Successful------------------");

			System.out.println("Would you like to add Test\n-------------------YES/NO------------------");
			String re=sc.nextLine();
			if(re.equalsIgnoreCase("yes"))
			{k=1;QuePaper qp=new QuePaper();
				System.out.println("ENTER TEST NUMBER:");
				int testId=sc.nextInt();
				sc.nextLine();
				qp.setId(testId);
				test.setTestId(testId);
				
				System.out.println("Enter test Title: ");
				String testTitle=sc.nextLine();
				test.setTestTitle(testTitle);
				
				System.out.println("Enter the number of questions you want to add in the test ");
				int num=sc.nextInt();
				sc.nextLine();
				qs.number(num);
				String option[][] = new String[num][4];
				for(int i=0; i<num;i++)
				{
					
					/*
					 * System.out.println("Enter the question: "+(i+1)); q=sc.nextLine();
					 * questions.put(i, q);
					 * 
					 * System.out.println("Enter Options for this question"); for (int k = 0; k<4;
					 * k++) { System.out.print((k+1)+"  "); option[i][k]=sc.nextLine(); }
					 * System.out.println("Enter the correct answer option number");
					 * a=sc.nextLine(); answers.put(i, a); qs.QuestionsService(questions.get(i),
					 * option, (Integer.parseInt(answers.get(i))));
					 */
					// System.out.println("Enter the question no:");
					 qp.setQno(i);
					 System.out.println("Enter the question ");
					 qp.setQue(sc.nextLine());
					 System.out.println("option 1");
					 qp.setOptionA(sc.nextLine());
					 System.out.println("option 2 ");
					 qp.setOptionB(sc.nextLine()); 
					 System.out.println("option 3");
					 qp.setOptionC(sc.nextLine());
					 System.out.println("option 4 ");
					 qp.setOptionD(sc.nextLine());
					 System.out.println("ryt ans  ");
					 qp.setRyt(sc.nextInt());
					 sc.nextLine();
					 list.add(qp);
				}
				/*
				 * FileOutputStream fout = new FileOutputStream("C:\\Yogesh\\1.txt");
				 * ObjectOutputStream oos = new ObjectOutputStream(fout); oos.writeObject(list);
				 * qs.disp();
				 */
			}
			
		
			else if(re.equalsIgnoreCase("NO"))
			{
				System.out.println("--------------THANK YOU--------------");
			}
			else
				System.out.println("-----------WRONG CHOICE-------------");
			
			
		}else if(userId == 2 && password.equalsIgnoreCase(map.get(2)))
		{
			System.out.println("-------------------USER Login Successful------------------");
			System.out.println("There is no test available for now \n login again: \n-------------Thank You-------------");
		}
		else
			System.out.println("-----------------WRONG INPUT--------------------");
		
		if(k==1)
		{
		
		System.out.println("Test is available now for the user\n-------------ENTER---YES/NO for login----------");
		String re2=sc.nextLine();
		if(re2.equalsIgnoreCase("yes"))
		{
		
			System.out.println("Enter user Id for login");
			int userId2 = sc.nextInt();
			sc.nextLine();
			System.out.println("�nter Password");
			String password2 = sc.nextLine();
			if(userId == 2 && password.equalsIgnoreCase(map.get(2)))
			{
				System.out.println("-------------------USER Login Successful------------------");
				System.out.println("WOULD YOU LIKE TO GIVE TEST\n-------------ENTER---YES/NO----------");
				String re3=sc.nextLine();
				if(re3.equalsIgnoreCase("yes"))
				{int marks=0;
					for(QuePaper q1:list)
					{
						System.out.println(q1.getQue());
						
							System.out.println("1  "+q1.getOptionA());
							System.out.println("2  "+q1.getOptionB());
							System.out.println("3   "+q1.getOptionC());
							System.out.println("4   "+q1.getOptionD());
						
							System.out.println("Enter your option no:");
							int res=sc.nextInt();
							sc.nextLine();
							if(q1.getRyt()==res)
							{
								marks++;
							}
							
					}
					System.out.println("marks= "+marks);
				}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
			}
		
		
		}
		else
			System.out.println("-------------------THANK YOU----------------");
		}
	}

}