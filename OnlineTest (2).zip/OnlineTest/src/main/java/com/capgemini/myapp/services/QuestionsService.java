package com.capgemini.myapp.services;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class QuestionsService {
	Scanner sca=new Scanner(System.in);
	
	public int num,ch;
	Map<Integer, String> questions = new HashMap<Integer, String>();
	Map<Integer, Integer> answers = new HashMap<Integer, Integer>();
	Map<Integer, Integer> choosenAnswers = new HashMap<Integer, Integer>();
	
	String option[][] = new String[100][4];
	public void number(int num)
	{
		this.num=num;
	}
	
	
	public void QuestionsService(String question,String options[][],int answer) {
		for(int i=0;i<num;i++)
		{
			questions.put(i, question);
			for(int k=0;k<4;k++)
			option[i][k]=options[i][k];
			answers.put(i, answer);
		}
		
	
		
		
		
	}

	public void disp()
	{
		for(int i=0;i<num;i++)
		{
			System.out.println(questions.get(i));
			for(int k=0;k<4;k++)
				System.out.println((k+1)+" "+option[i][k]+"    ");
			System.out.println();
			System.out.println("Enter your choice");
			ch=sca.nextInt();
			choosenAnswers.put(i,ch );
		}
		
		
	}
	
	
	
	
	
	
	
	
	
	
}
