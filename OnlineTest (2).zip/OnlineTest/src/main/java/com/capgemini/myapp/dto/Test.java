package com.capgemini.myapp.dto;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

public class Test {
	public Test() 
	{
		
	}
	private int testId;      
	private String testTitle;
	private List<Question> testQuestions;
	private double testTotalMarks;
	private double totalMarksScored;
	private Question currentQuestion;
	
	
	public int getTestId() 
	{
		return testId;
	}
	public void setTestId(int testId) 
	{
		this.testId = testId;
	}
	
	public String getTestTitle() 
	{
		return testTitle;
	}
	public void setTestTitle(String testTitle) 
	{
		this.testTitle = testTitle;
	}
	
	public double getTotalMarksScored() 
	{
		return totalMarksScored;
	}
	public void setTotalMarksScored(double totalMarksScored) 
	{
		this.totalMarksScored = totalMarksScored;
	}
	
	public Question getCurrentQuestion() 
	{
		return currentQuestion;
	}
	public void setCurrentQuestion(Question currentQuestion) 
	{
		this.currentQuestion = currentQuestion;
	}
	
	
	
	
	public double getTestTotalMarks() 
	{
		return testTotalMarks;
	}
	public void setTestTotalMarks(double testTotalMarks) 
	{
		this.testTotalMarks = testTotalMarks;
	}
	
	public List<Question> getTestQuestions() 
	{
		return testQuestions;
	}
	public void setTestQuestions(List<Question> testQuestions) 
	{
		this.testQuestions = testQuestions;
	}
	
	@Override
	public String toString() 
	{
		// TODO Auto-generated method stub
		return super.toString();
	}

	
	
	
	
	
}
