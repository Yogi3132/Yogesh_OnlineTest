package p1;

public class QuizCode {

	String question[] = new String[3];
	String option[][] = new String[3][4];
	String answer[] = new String[3];

	public QuizCode() {
		super();
		// TODO Auto-generated constructor stub
		
		question[0] = "1. 1+1";
		
		option[0][0] = "1. 9";
		option[0][1] = "2. 87";
		option[0][2] = "3. 2";
		option[0][3] = "4. 0";
		
		answer[0] = "3";
		
		
		question[1] = "2. 1+2";
		
		option[1][0] = "1. 7";
		option[1][1] = "2. 3";
		option[1][2] = "3. 7 ";
		option[1][3] = "4. 4";
		
		answer[1] = "2";
		
		
		question[2] = "1. 1+55";
		
		option[2][0] = "1. 56";
		option[2][1] = "2. 3";
		option[2][2] = "3. 45";
		option[2][3] = "4. 55";
		
		answer[2] = "1";
		
		
	}

	public static void main(String[] args) {
		int s=0;
		
		QuizCode qc = new QuizCode();
		
		
		for (int q = 0; q < qc.question.length; q++) {
			System.out.println(qc.question[q]);
			
			for(int op = 0;op<4;op++)
			{
				System.out.println(qc.option[q][op]);
			}
		
			System.out.println("Enter Answer ");
			String userAnswer = new java.util.Scanner(System.in).nextLine();
			
			if(userAnswer.equals(qc.answer[q]))
			{
				s++;
			}
		
		}
		
		
		System.out.println("Your Score= "+s);
	}

}
